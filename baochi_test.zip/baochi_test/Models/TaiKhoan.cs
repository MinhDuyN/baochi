﻿using System;
using System.Collections.Generic;

namespace baochi_test.Models;

public partial class TaiKhoan
{
    public string TaiKhoan1 { get; set; } = null!;

    public string? MatKhau { get; set; }
}
